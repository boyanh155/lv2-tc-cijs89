import React from 'react';
import './App.css';
import Header from './component/Header';
import Content from './component/Content';
import Footer from './component/Footer';

[].reduce()
const App = () => {
  return (
    <div className="app">
      <Header />
      <Content />
      <Footer />
    </div>
  );
};

export default App;
