import React from 'react';
import ItemList from './ItemList';

const Content = () => {
  return (
    <section className="content">
      <h2>Content Section</h2>
      <div className="description">
        <p>This is the content of the app. It can include various elements and components.</p>
        <button>Click Me</button>
      </div>
      <ItemList />
    </section>
  );
};

export default Content;
