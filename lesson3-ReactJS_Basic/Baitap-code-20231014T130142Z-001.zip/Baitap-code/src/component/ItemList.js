import React from 'react';

const ItemList = () => {
  const items = ['Item 1', 'Item 2', 'Item 3'];

  return (
    <ul className="item-list">
      {items.map((item, index) => (
        <li key={index}>{item}</li>
      ))}
    </ul>
  );
};

export default ItemList;
